import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';
import 'package:lottie/lottie.dart';

import 'package:assets_audio_player/assets_audio_player.dart';

void main() {
  runApp(MyApp());
}

class Todo {
  String title;
  bool isDone;
  bool isFlagged; // New property for flag

  Todo({
    required this.title,
    this.isDone = false,
    this.isFlagged = false,
  });
}


class TodoApp extends StatefulWidget {
  @override
  _TodoAppState createState() => _TodoAppState();
}

class _TodoAppState extends State<TodoApp> with TickerProviderStateMixin {
  List<Todo> todos = [];
  TextEditingController controller = TextEditingController();
  late final AnimationController _controller;

  

  @override
  void initState() {
    super.initState();
    loadTodos();
    _controller = AnimationController(vsync: this);
  }

  void onComplete(index) async {
      final completedTodo = todos.removeAt(index);
    saveTodos();
  AssetsAudioPlayer.newPlayer().open(
    Audio("assets/ting.mp3"),
    autoStart: true
  );
    setState(() {});

    // Display a toast using Fluttertoast
    Fluttertoast.showToast(
      msg: 'Task completed',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );

  }

  void loadTodos() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? todoList = prefs.getStringList('todos');
    if (todoList != null) {
      todos = todoList.map((todo) => Todo(title: todo)).toList();
      setState(() {});
    }
  }

  void saveTodos() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> todoList = todos.map((todo) => todo.title).toList();
    prefs.setStringList('todos', todoList);
  }

  void addTodo() {
    String text = controller.text.trim();
    if (text.isNotEmpty) {
      todos.add(Todo(title: text));
      saveTodos();
      controller.clear();
      setState(() {});
    }
  }

  void toggleTodoState(int index) {
    todos[index].isDone = !todos[index].isDone;
    if (todos[index].isDone) {
      onComplete(index);
    } else {
      saveTodos();
    }
    setState(() {});
  }

  void removeTodo(int index) {
    final removedTodo = todos.removeAt(index);
    saveTodos();
    setState(() {});
AssetsAudioPlayer.newPlayer().open(
    Audio("assets/crush.mp3"),
    autoStart: true
  );
    // Display a toast using Fluttertoast
    Fluttertoast.showToast(
      msg: 'Task "${removedTodo.title}" removed',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }
void toggleFlag(int index) {
  todos[index].isFlagged = !todos[index].isFlagged;
  saveTodos();
  setState(() {});
}
Widget build(BuildContext context) {
   Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.red;
    }
  return Scaffold(
    appBar: AppBar(
      title: Text('ToDo'),
    ),
    backgroundColor: Colors.white.withOpacity(0.5),
    body: Column(
      children: <Widget>[
        Expanded(
          child: todos.isEmpty
              ? Center(
  // Display a message and an icon when the list is empty
  child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Lottie.network(
          'https://lottie.host/2320a028-3561-4cf3-8fdb-e2e705c1f96c/6MzV9aiyzU.json',
          height: 150),
      Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1), // Shadow color
              spreadRadius: 5, // Spread radius
              blurRadius: 7, // Blur radius
              offset: Offset(0, 3), // Offset
            ),
          ],
        ),
        child: Text(
          'No tasks',
          style: TextStyle(fontSize: 18,color: Colors.grey),
        ),
      ),
    ],
  ),
)

              :ListView.builder(
  itemCount: todos.length,
  itemBuilder: (context, index) {
    final todo = todos[index];
    return Dismissible(
      key: Key(todo.title),
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: EdgeInsets.only(right: 20.0),
        child: Lottie.network(
          'https://lottie.host/a89e9926-c198-4e97-8a00-63997b5bcfd4/bwarywa3yZ.json'),
      ),
      onDismissed: (_) => removeTodo(index),
      child: ListTile(
        leading: Checkbox(
        
         
         
  
          
          hoverColor: Colors.yellow.withOpacity(0.4),

          value: todo.isDone,
          onChanged: (_) => toggleTodoState(index),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                todo.title,
                style: TextStyle(
                  color: Colors.black,
                  decoration: todo.isDone ? TextDecoration.lineThrough : null,
                ),
              ),
            ),
            IconButton(
              icon: Icon(
                todo.isFlagged ? Icons.flag : Icons.star,
                color: todo.isFlagged ? Colors.red : Colors.grey.withOpacity(0.5),
              ),
              onPressed: () {
                toggleFlag(index);
              },
            ),
          ],
        ),
        trailing: Lottie.network(
          'https://lottie.host/d338554f-26ab-472d-a1a6-e46f759fee4d/45qqTRoVj3.json',
          controller: _controller,
          onLoaded: (Composition) {
            _controller
              ..duration = Composition.duration
              ..forward();
          },
        ),
      ),
    );
  },
)

        ),
      Padding(
  padding: const EdgeInsets.all(16.0),
  child: Card(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(15.0),
    
    ),
    elevation: 4,
    color: Color(0xFFE5E4E2),
    child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        
        controller: controller,
        decoration: InputDecoration(
          labelText: 'Add a new todo',
          border: InputBorder.none, // Remove the underline
          suffixIcon: Lottie.network(
            'https://lottie.host/004e806d-8f36-4402-887a-811ea44565ab/fUYyAr9TF1.json',
            height: 20,
          ),
        ),
        onSubmitted: (_) => addTodo(),
      ),
    ),
  ),
),

      ],
    ),
  );
}


}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AnimatedSplashScreen(
        splash: Lottie.network('https://lottie.host/779b648e-51c6-496f-ba66-23908597c78c/nc59PRal4c.json'),
        nextScreen: TodoApp(),
        splashTransition: SplashTransition.scaleTransition,
        pageTransitionType: PageTransitionType.fade,
        duration: 2500,
      ),
    );
  }
}
